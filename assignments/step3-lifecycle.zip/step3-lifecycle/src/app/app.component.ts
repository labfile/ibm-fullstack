import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <h1>Main App Component</h1>
  <input type="number">
  <button>Set Power</button>
  <hr>
  <app-child></app-child>
  `,
  styles: []
})
export class AppComponent {
  title = 'step3-lifecycle';
}
