import {UPDATE_MOVIES} from '../actions/updateMovies';

// Recieve type and payload from action and return payload.
// Movies are being updated by the action of the string in our payload.

const movielistReducer = (state = {}, action) => {
    switch(action.type) {
        case UPDATE_MOVIES : return { name: action.payload }
        default : return state
    };
};

export default movielistReducer;
