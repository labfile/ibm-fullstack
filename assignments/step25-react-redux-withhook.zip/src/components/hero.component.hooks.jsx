import { addHero } from "../redux";
import { useDispatch, useSelector } from "react-redux";

let HeroHookComp = ()=> {
    let numberOfHeroes = useSelector( state => state.numberOfHeroes );
    let dispatch = useDispatch();
        return <div>
                   <h1>Avengers Enrollment Program with Hooks</h1>
                   <h2>Number of Avengers recruited : { numberOfHeroes }</h2>
                   <button onClick={ ()=> dispatch(addHero())}>Add Avenger</button>
               </div>
}

export default  HeroHookComp;