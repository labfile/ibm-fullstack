import { Component } from "react";
import { Provider } from "react-redux";
import HeroComp from "./components/hero.component";
import HeroHookComp from "./components/hero.component.hooks";
import store from "./redux/store";

class Main extends Component{
    render(){
        return <div>
                    <Provider store={ store }> 
                        <HeroComp/> 
                        <HeroHookComp/>
                    </Provider>
                </div>
    }
}

export default Main;