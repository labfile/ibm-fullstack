import { Component, Input } from "@angular/core";
import { HeroService } from "./hero.services";

@Component({
    selector : 'app-header',
    template : `
    <h3>App Version {{ appVersion  }}</h3>
     <ul class="nav justify-content-center">
        <li  class="nav-item" *ngFor="let hero of datalist">
            <a class="nav-link" href="#">{{ hero.title }}</a>
        </li>
    </ul>
    `
})
export class HeaderComp{
    @Input() datalist:any = [];
    appVersion = 0;
    constructor(private hs:HeroService){
      this.datalist = this.hs.getData();
      this.appVersion = this.hs.getVersion();
      setInterval(()=>{
          this.setAppVersion()
        },100)
    }
    setAppVersion(){
        this.appVersion = this.hs.getVersion();
    }
}
/* export class HeaderComp{
    @Input() datalist:any = [];
    appVersion = 0;
    hs:HeroService = new HeroService();
    constructor(){
      this.datalist = this.hs.getData();
      this.appVersion = this.hs.getVersion();
    }
} */