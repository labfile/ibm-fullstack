import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
   <div class="container">
     <h1>Angular Communication Assignment </h1>
     <hr>
    <app-header></app-header> 
    <app-grid></app-grid>
     <!-- <p> {{ herolist | json }} </p> -->
   </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'step3-pipes';
}
