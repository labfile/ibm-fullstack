export class HeroService{
    movies:any = ['batman begins'];

    getMovie(){
        return this.movies;
    }
    addMovie(nmovie:any){
        this.movies.push(nmovie);
    }
}