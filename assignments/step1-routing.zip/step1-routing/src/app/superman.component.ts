import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HeroService } from './herolist.service';

@Component({
  selector: 'app-superman',
  template: `
    <h2> Superman works! </h2>
    <label for="movieti">Add New Movie Here 
      <input #nm id="movieti" type="text">
    </label>
    <button (click)="addnewmovie(nm.value)">Add Movie</button>
    <hr>
    <h3>Power is : {{ power }}</h3>
    <ol>
      <li *ngFor="let movie of compMovies">{{ movie }}</li>
    </ol>
  `,
  styles: []
})
export class SupermanComponent implements OnInit {
  compMovies:any =[];
  power = 0;
  constructor(private hs:HeroService, private ar:ActivatedRoute) { }
  reload(){
    this.compMovies = this.hs.getMovie();
  }
  ngOnInit(): void {
   this.reload();
   this.power = this.ar.snapshot.params['pow'];
  }
  
  addnewmovie(nmovie:any){
    this.hs.addMovie(nmovie);
    this.reload();
  }

}
