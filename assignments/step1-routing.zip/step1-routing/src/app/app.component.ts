import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
   <h1>Routing 101</h1>
   Power to Superman
   <input [(ngModel)]="power" type="range">{{ power }}
   <ul>
    <li> <a routerLinkActive="selected" [routerLinkActiveOptions]="{exact : true }" [routerLink]="['/']">Home</a> </li>
    <li> <a routerLinkActive="selected" [routerLink]="['batman']">Batman</a> </li>
    <li> <a routerLinkActive="selected" [routerLinkActiveOptions]="{exact : true }" [routerLink]="['superman']">Superman</a> </li>
    <li> <a routerLinkActive="selected" [routerLink]="['superman',power]">Superman with Params</a> </li>
    <li> <a routerLinkActive="selected" [routerLink]="['aquaman']">Aquaman</a> </li>
    <li> <a routerLinkActive="selected" [routerLink]="['flash']">Flash</a> </li>
    <li> <a routerLinkActive="selected" [routerLink]="['hulk']">Hulk</a> </li>
   </ul>
   <router-outlet></router-outlet>
  `,
  styles: [`
  li{
    list-style : none;
    display : inline-block;
    text-decoration : none;
    width : 200px;
    text-align : center;
  }
  .selected{
    background-color : crimson;
    padding : 10px;
    color : white;
    text-decoration : none;
  }
  `]
})
export class AppComponent {
  power = 0;
  title = 'step1-routing';
}
