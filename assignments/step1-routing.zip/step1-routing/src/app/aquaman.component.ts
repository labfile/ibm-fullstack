import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aquaman',
  template: `
    <h2>Aquaman works!</h2>
  `,
  styles: [
  ]
})
export class AquamanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
