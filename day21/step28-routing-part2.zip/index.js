import { createRoot } from "react-dom/client";
import AppComp from "./app";

createRoot(document.getElementById("root")).render(<AppComp/>)