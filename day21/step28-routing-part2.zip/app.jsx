import React, { Component } from 'react';
import { BrowserRouter, Link, NavLink, Route, Routes } from "react-router-dom";
import JusticeLeagueComp from "./components/justiceleague.component";
import BatmanComp from "./components/batman.component";
import AquamanComp from './components/aquaman.component';
import SupermanComp from './components/superman.component';
import NotFound from './components/notfound.component';
import "./components/mystyle.css";

class AppComp extends Component{
    state = {
        quantity : 0
    }
    render(){
        return <div className="container">
                 <h1>Justice League Heroes</h1>
                 <h2>Quantity : { this.state.quantity }</h2>
                 <input type="range" onInput={(evt)=> this.setState({ quantity : evt.target.value })} />
                 <BrowserRouter>
                 {/* 
                 <ul>
                    <li><a href="/">Home</a></li>
                    <li><a href="/batman">Batman</a></li>
                    <li><a href="/aquaman">Aquaman</a></li>
                    <li><a href="/superman">Superman</a></li>
                 </ul> 
                 */}
                {/*  
                <ul>
                    <li><Link to="/">Home</Link></li>
                    <li><Link to="/batman">Batman</Link></li>
                    <li><Link to="/aquaman">Aquaman</Link></li>
                    <li><Link to="/superman">Superman</Link></li>
                 </ul> 
                 */}
                  <ul>
                    <li><NavLink className={ ( {isActive} ) => isActive ? 'boxer' : null } to="/">Home</NavLink></li>
                    <li><NavLink className={ ( {isActive} ) => isActive ? 'boxer' : null } to="/batman">Batman</NavLink></li>
                    <li><NavLink className={ ( {isActive} ) => isActive ? 'boxer' : null } to="/aquaman">Aquaman</NavLink></li>
                    <li><NavLink className={ ( {isActive} ) => isActive ? 'boxer' : null } to={ '/superman/'+this.state.quantity }>Superman</NavLink></li>
                    <li><NavLink className={ ( {isActive} ) => isActive ? 'boxer' : null } to="/flash">Flash</NavLink></li>
                 </ul>
                    <Routes>
                        <Route path="/" element={<JusticeLeagueComp/>}/>
                        <Route path="/batman" element={<BatmanComp/>}/>
                        <Route path="/aquaman" element={<AquamanComp/>}/>
                        <Route path="/superman/:qty" element={<SupermanComp/>}/>
                        <Route path="*" element={<NotFound/>}/>
                    </Routes>
                 </BrowserRouter>
               </div>
    }
}

export default AppComp;