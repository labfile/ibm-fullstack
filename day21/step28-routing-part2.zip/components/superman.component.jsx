import React, { Component } from 'react';
import { useParams } from 'react-router-dom';

/* class SupermanComp extends Component{
    render(){
        return <div className="container">
                 <h1>Superman Component</h1>
               </div>
    }
}

export default SupermanComp; */

let SupermanComp = () => {
    let { qty } = useParams();
    return <div className="container">
                <h1>Superman Component</h1>
                <h2>Quantity is { qty || 'not provided'}</h2>
            </div>
}

export default SupermanComp;