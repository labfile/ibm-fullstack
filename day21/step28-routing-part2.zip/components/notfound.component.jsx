import React, { Component } from 'react';

class NotFound extends Component{
    render(){
        return <div className="container">
                 <h1>404 Requested File not found</h1>
               </div>
    }
}

export default NotFound;