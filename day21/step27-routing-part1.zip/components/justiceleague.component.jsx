import React, { Component } from 'react';

class JusticeLeagueComp extends Component{
    render(){
        return <div className="container">
                 <h1>JusticeLeague Home Component</h1>
               </div>
    }
}

export default JusticeLeagueComp;