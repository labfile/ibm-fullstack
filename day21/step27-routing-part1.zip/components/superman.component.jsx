import React, { Component } from 'react';

class SupermanComp extends Component{
    render(){
        return <div className="container">
                 <h1>Superman Component</h1>
               </div>
    }
}

export default SupermanComp;