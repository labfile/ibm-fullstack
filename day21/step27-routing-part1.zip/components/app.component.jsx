import React, { Component } from 'react';
import "./mystyle.css";

class AppComp extends Component{
    render(){
        return <div className="container">
                 <h1>Justice League Heroes</h1>
               </div>
    }
}

export default AppComp;