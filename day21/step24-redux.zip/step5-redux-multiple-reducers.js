let redux = require("redux");
let createStore = redux.createStore;
let combineReducers = redux.combineReducers;
// ACTION
let ADD_HERO = "ADD_HERO";
let REMOVE_HERO = "REMOVE_HERO";
// ACTION
let ADD_MOVIE = "ADD_MOVIE";
let REMOVE_MOVIE = "REMOVE_MOVIE";
// ACTION CREATOR
let addHero = function (){
    return {
        type : ADD_HERO
    }
}
let removeHero = function (){
    return {
        type : REMOVE_HERO
    }
}
let addMovie = function (){
    return {
        type : ADD_MOVIE
    }
}
let removeMovie = function (){
    return {
        type : REMOVE_MOVIE
    }
}
// initial / default state
let initialHeroState = {
    numberOfHeroes : 0
}
let initialMovieState = {
    numberOfMovies : 0
}
//reducer 
let heroReducer = (state = initialHeroState, action)=>{
    switch(action.type){
        case ADD_HERO : return { ...state, numberOfHeroes : state.numberOfHeroes + 1 }
        case REMOVE_HERO : return {...state,  numberOfHeroes : state.numberOfHeroes - 1 }
        default : return state
    }
};
let movieReducer = (state = initialMovieState, action)=>{
    switch(action.type){
        case ADD_MOVIE : return { ...state, numberOfMovies : state.numberOfMovies + 1 }
        case REMOVE_MOVIE : return { ...state, numberOfMovies : state.numberOfMovies - 1 }
        default : return state
    }
};
let rootReducers = combineReducers({
    heroes : heroReducer,
    movies : movieReducer
})
// create store
let store = createStore(rootReducers);
console.log( "default ", store.getState() );
// subscription / unsubscription
let unsubscribe = store.subscribe( ()=>{
    console.log("subscribed : ", store.getState() );
});
// dispatcher
store.dispatch( addHero() ); // 1
store.dispatch( addHero() ); // 2
store.dispatch( removeHero() ); // 1
store.dispatch( addHero() ); // 2
store.dispatch( addHero() ); // 3
store.dispatch( removeHero() ); // 2
// dispatcher
store.dispatch( addMovie() ); // 1
store.dispatch( addMovie() ); // 2
store.dispatch( removeMovie() ); // 1
store.dispatch( addMovie() ); // 2
store.dispatch( addMovie() ); // 3
store.dispatch( removeMovie() ); // 2
unsubscribe();
console.log("unsubscribed ");