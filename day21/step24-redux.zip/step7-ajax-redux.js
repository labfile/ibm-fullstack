let redux = require("redux");
let thunkMiddleWare = require("redux-thunk").default;
let axios = require("axios");
// ===============
let createStore = redux.createStore;
let applyMiddleWare = redux.applyMiddleware;

// ACTION
let USER_REQUEST = "USER_REQUEST";
let USER_SUCCESS = "USER_SUCCESS";
let USER_ERROR = "USER_ERROR";

// ACTION CREATOR
let fetchUsersRequest = ()=>{
    return {
        type : USER_REQUEST
    }
}
let fetchUsersSuccess = (users)=>{
    return {
        type : USER_SUCCESS,
        payload : users
    }
}
let fetchUsersError = (error)=>{
    return {
        type : USER_ERROR,
        payload : error
    }
}

// initial / default state
let initialState = {
    loading : false,
    users : [],
    error : ''
}
// reducer 
let userReducer = (state = initialState, action) => {
    switch(action.type){
        case USER_REQUEST : return {  ...state,  loading : true }
        case USER_SUCCESS : return {  ...state,  loading : false, users : action.payload }
        case USER_ERROR : return { ...state, loading : false, users : [], error : action.payload }
        default : return state
    }
};

// create store
let store = createStore(userReducer, applyMiddleWare(thunkMiddleWare));

let thunkFetchUsers = ()=>{
    return function(dispatch){
        dispatch( fetchUsersRequest() )
    }
}

let thunkAjaxFetchUsers = () => {
    return function(dispatch){
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then(res =>  dispatch( fetchUsersSuccess( res.data )))
        .catch(error => dispatch( fetchUsersError(error)) )
    }
}

// subscription / unsubscription
store.subscribe(()=>{
    console.log(store.getState());
});
store.dispatch( thunkFetchUsers() );
// dispatcher
store.dispatch( thunkAjaxFetchUsers() );