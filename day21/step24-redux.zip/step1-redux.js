// action : object that has type and payload
// action creator : is a function that returns an action
// initial state : holds the default value
// reducer : a pure function that modifies the store
// store : is a place for all states to be kept
// store subscription / unsubscription
// dispatcher

let redux = require("redux");
let createStore = redux.createStore;
// ACTION
let ADD_HERO = "ADD_HERO";
// ACTION CREATOR
let addHero = function (){
    return {
        type : ADD_HERO
    }
}
// initial / default state
let initialState = {
    numberOfHeroes : 0
}
//reducer 
let reducer = (state = initialState, action)=>{
    switch(action.type){
        case ADD_HERO : return { numberOfHeroes : state.numberOfHeroes + 1 }
        default : return state
    }
};
// create store
let store = createStore(reducer);
console.log( "default ", store.getState() );
// subscription / unsubscription
store.subscribe( ()=>{
    console.log("subscribed : ", store.getState() );
});
// dispatcher
store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( addHero() );