let redux = require("redux");
let createStore = redux.createStore;
// ACTION
let ADD_HERO = "ADD_HERO";
// ACTION CREATOR
let addHero = function (){
    return {
        type : ADD_HERO
    }
}
// initial / default state
let initialState = {
    numberOfHeroes : 0
}
//reducer 
let reducer = (state = initialState, action)=>{
    switch(action.type){
        case ADD_HERO : return { numberOfHeroes : state.numberOfHeroes + 1 }
        default : return state
    }
};
// create store
let store = createStore(reducer);
console.log( "default ", store.getState() );
// subscription / unsubscription
let unsubscribe = store.subscribe( ()=>{
    console.log("subscribed : ", store.getState() );
});
// dispatcher
store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( addHero() );
unsubscribe();
console.log("unsubscribed ");
store.dispatch( addHero() );
store.dispatch( addHero() );