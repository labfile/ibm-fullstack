import App from './app';

describe("Testing component", ()=>{
    let app = null;
    beforeEach(()=>{
        app = new App();
        console.log("Before each was called")
    })
    afterEach(()=>{
        console.log("After each was called")
    })
    beforeAll(()=>{
        console.log("Before all was called")
    })
    afterAll(()=>{
        console.log("After all was called")
    })

    describe("checking for power", ()=>{
        test('should have power', ()=>{
            expect(app.state.power).toBeDefined();
        })
        test('should power to be greater 2', ()=>{
            expect(app.state.power).toBeGreaterThan(2);
        })
        test('should power to be lessthan 10', ()=>{
            expect(app.state.power).toBeLessThan(10);
        })
    })

    describe("checking for title", ()=>{
        test('should have title', ()=>{
            expect(app.state.title).toBeDefined();
        })
        test('should check title to be ibmindia', ()=>{
            expect(app.state.title).toBe('ibm');
        })
    })
    
})