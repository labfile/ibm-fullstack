import { Component } from "react";

class App extends Component{
    state = {
        power : 5,
        title : 'ibm'
    }
    render(){
        return <div>
                    <h1>Welcome to your life</h1>
               </div>
    }
}

export default App;